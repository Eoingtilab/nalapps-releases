# 변경이력

## [Unreleased]

### 예정

- 다음 우편번호 검색 UI
- Checkout Blocks Store API 검증
- 국내 택배사 배송조회
- 쇼핑피드·분석·상담버튼
- Classic Checkout·Checkout Blocks·HPOS 실제 스테이징 회귀검사

## [0.1.0-rc.1] - 2026-07-17

### 추가

- 설치 가능한 `nalapps-korean-woocommerce.php` 메인 플러그인
- WooCommerce 및 NalApps Commerce Core 의존성 안내
- 대한민국 주소 필드 라벨·순서와 주소 출력 형식
- 대한민국 우편번호 5자리 정규화·검증
- 대한민국 청구지 휴대전화 정규화·검증
- Core 관리자 메뉴 하위 통합 상태 화면
- HPOS 호환 선언
- 배포 매니페스트, 런타임 테스트와 설치 ZIP 계약
- PHP 8.1·8.2·8.3 CI

### 변경

- 한국형 주소·전화 검증을 대한민국 주소에만 적용하도록 범위를 격리
- 기존 필드 속성을 보존하면서 필요한 속성만 병합
- Checkout Blocks는 미구현 기능을 지원한다고 표시하지 않도록 호환 선언을 fail-closed로 변경

### 보안 및 안정성

- 관리자 화면 `manage_woocommerce` 권한 검증
- 입력값 정제 후 국가별 검증
- 외부 서비스·API 키 없이 로컬 필드 처리만 수행
- 비한국 주소와 국제 전화번호를 임의 변환하지 않음

### 제한

- 현재 RC는 Classic Checkout 기준입니다.
- 다음 우편번호 검색, 배송조회, 쇼핑피드, 분석과 상담 기능은 후속 RC에서 제공합니다.
