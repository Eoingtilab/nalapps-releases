<?php
/**
 * Plugin Name: NalApps Korean WooCommerce
 * Plugin URI: https://app.nal.la/
 * Description: 국내 WooCommerce 운영에 필요한 주소, 연락처와 주문 입력 흐름을 보완하는 날라앱스 커머스 공식 애드온입니다.
 * Version: 0.1.0-rc.1
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Requires Plugins: woocommerce
 * Author: Eoingti Lab Inc.
 * Text Domain: nalapps-korean-woocommerce
 */

defined( 'ABSPATH' ) || exit;

define( 'NALAPPS_KOREAN_WC_VERSION', '0.1.0-rc.1' );
define( 'NALAPPS_KOREAN_WC_FILE', __FILE__ );

add_action(
	'before_woocommerce_init',
	static function (): void {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, false );
		}
	}
);

final class NalApps_Korean_WooCommerce {
	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'boot' ), 30 );
	}

	public function boot(): void {
		if ( ! defined( 'NALAPPS_COMMERCE_CORE_VERSION' ) ) {
			add_action( 'admin_notices', array( $this, 'core_required_notice' ) );
			return;
		}

		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_required_notice' ) );
			return;
		}

		add_filter( 'woocommerce_get_country_locale', array( $this, 'country_locale' ) );
		add_filter( 'woocommerce_billing_fields', array( $this, 'billing_fields' ), 10, 2 );
		add_filter( 'woocommerce_checkout_posted_data', array( $this, 'normalize_checkout_data' ) );
		add_action( 'woocommerce_after_checkout_validation', array( $this, 'validate_checkout' ), 10, 2 );
		add_filter( 'woocommerce_localisation_address_formats', array( $this, 'address_formats' ) );
		add_action( 'admin_menu', array( $this, 'admin_menu' ), 99 );
	}

	public function core_required_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-error"><p><strong>' . esc_html__( '한국형 우커머스', 'nalapps-korean-woocommerce' ) . '</strong> ' . esc_html__( '애드온을 사용하려면 NalApps Commerce Core를 먼저 설치하고 활성화해 주세요.', 'nalapps-korean-woocommerce' ) . '</p></div>';
	}

	public function woocommerce_required_notice(): void {
		if ( ! current_user_can( 'activate_plugins' ) ) {
			return;
		}

		echo '<div class="notice notice-error"><p><strong>' . esc_html__( '한국형 우커머스', 'nalapps-korean-woocommerce' ) . '</strong> ' . esc_html__( '애드온을 사용하려면 WooCommerce를 먼저 설치하고 활성화해 주세요.', 'nalapps-korean-woocommerce' ) . '</p></div>';
	}

	public function country_locale( array $locale ): array {
		$locale['KR'] = isset( $locale['KR'] ) && is_array( $locale['KR'] ) ? $locale['KR'] : array();

		$fields = array(
			'country'   => array(
				'priority' => 10,
			),
			'postcode'  => array(
				'label'       => __( '우편번호', 'nalapps-korean-woocommerce' ),
				'placeholder' => __( '우편번호 5자리', 'nalapps-korean-woocommerce' ),
				'required'    => true,
				'priority'    => 20,
			),
			'state'     => array(
				'label'    => __( '시/도', 'nalapps-korean-woocommerce' ),
				'priority' => 30,
			),
			'city'      => array(
				'label'    => __( '시/군/구', 'nalapps-korean-woocommerce' ),
				'priority' => 40,
			),
			'address_1' => array(
				'label'       => __( '기본 주소', 'nalapps-korean-woocommerce' ),
				'placeholder' => __( '도로명 또는 지번 주소', 'nalapps-korean-woocommerce' ),
				'priority'    => 50,
			),
			'address_2' => array(
				'label'       => __( '상세 주소', 'nalapps-korean-woocommerce' ),
				'placeholder' => __( '동·호수 등 상세 주소', 'nalapps-korean-woocommerce' ),
				'priority'    => 60,
			),
		);

		foreach ( $fields as $field_key => $properties ) {
			$current                    = isset( $locale['KR'][ $field_key ] ) && is_array( $locale['KR'][ $field_key ] ) ? $locale['KR'][ $field_key ] : array();
			$locale['KR'][ $field_key ] = array_merge( $current, $properties );
		}

		return $locale;
	}

	public function billing_fields( array $fields, string $country = '' ): array {
		if ( 'KR' !== strtoupper( $country ) || ! isset( $fields['billing_phone'] ) ) {
			return $fields;
		}

		$fields['billing_phone']['label']       = __( '휴대전화', 'nalapps-korean-woocommerce' );
		$fields['billing_phone']['placeholder'] = '010-1234-5678';
		$fields['billing_phone']['required']    = true;
		$fields['billing_phone']['priority']    = 25;
		$fields['billing_phone']['class']       = array( 'form-row-wide' );
		$fields['billing_phone']['custom_attributes'] = array_merge(
			isset( $fields['billing_phone']['custom_attributes'] ) && is_array( $fields['billing_phone']['custom_attributes'] ) ? $fields['billing_phone']['custom_attributes'] : array(),
			array(
				'inputmode'    => 'tel',
				'autocomplete' => 'tel',
			)
		);

		return $fields;
	}

	public function normalize_checkout_data( array $data ): array {
		$billing_country = strtoupper( sanitize_text_field( (string) ( $data['billing_country'] ?? '' ) ) );
		if ( 'KR' === $billing_country ) {
			$data['billing_phone']    = $this->format_phone( (string) ( $data['billing_phone'] ?? '' ) );
			$data['billing_postcode'] = $this->format_postcode( (string) ( $data['billing_postcode'] ?? '' ) );
		}

		$shipping_country = strtoupper( sanitize_text_field( (string) ( $data['shipping_country'] ?? '' ) ) );
		if ( 'KR' === $shipping_country ) {
			$data['shipping_postcode'] = $this->format_postcode( (string) ( $data['shipping_postcode'] ?? '' ) );
		}

		return $data;
	}

	public function validate_checkout( array $data, WP_Error $errors ): void {
		$billing_country = strtoupper( sanitize_text_field( (string) ( $data['billing_country'] ?? '' ) ) );
		if ( 'KR' === $billing_country ) {
			$phone = preg_replace( '/\D+/', '', (string) ( $data['billing_phone'] ?? '' ) );
			if ( ! is_string( $phone ) || ! preg_match( '/^01[016789]\d{7,8}$/', $phone ) ) {
				$errors->add( 'billing_phone', __( '올바른 국내 휴대전화 번호를 입력해 주세요.', 'nalapps-korean-woocommerce' ) );
			}

			if ( ! $this->is_valid_postcode( (string) ( $data['billing_postcode'] ?? '' ) ) ) {
				$errors->add( 'billing_postcode', __( '우편번호 5자리를 입력해 주세요.', 'nalapps-korean-woocommerce' ) );
			}
		}

		$ship_to_different = ! empty( $data['ship_to_different_address'] );
		$shipping_country  = strtoupper( sanitize_text_field( (string) ( $data['shipping_country'] ?? '' ) ) );
		if ( $ship_to_different && 'KR' === $shipping_country && ! $this->is_valid_postcode( (string) ( $data['shipping_postcode'] ?? '' ) ) ) {
			$errors->add( 'shipping_postcode', __( '배송지 우편번호 5자리를 입력해 주세요.', 'nalapps-korean-woocommerce' ) );
		}
	}

	public function address_formats( array $formats ): array {
		$formats['KR'] = "{last_name}{first_name}\n{postcode}\n{state} {city}\n{address_1} {address_2}\n{country}";
		return $formats;
	}

	public function admin_menu(): void {
		add_submenu_page(
			'nalapps-commerce',
			__( '한국형 우커머스', 'nalapps-korean-woocommerce' ),
			__( '한국형 우커머스', 'nalapps-korean-woocommerce' ),
			'manage_woocommerce',
			'nalapps-korean-woocommerce',
			array( $this, 'render_admin' )
		);
	}

	public function render_admin(): void {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( '이 화면에 접근할 권한이 없습니다.', 'nalapps-korean-woocommerce' ) );
		}
		?>
		<div class="wrap">
			<h1><?php echo esc_html__( '한국형 우커머스', 'nalapps-korean-woocommerce' ); ?></h1>
			<p><?php echo esc_html__( '대한민국 주소, 우편번호와 휴대전화 검증을 Classic Checkout에 적용합니다.', 'nalapps-korean-woocommerce' ); ?></p>
			<table class="widefat striped" style="max-width:760px">
				<tbody>
				<tr><th><?php echo esc_html__( '플러그인 버전', 'nalapps-korean-woocommerce' ); ?></th><td><?php echo esc_html( NALAPPS_KOREAN_WC_VERSION ); ?></td></tr>
				<tr><th>WooCommerce</th><td><?php echo esc_html( defined( 'WC_VERSION' ) ? WC_VERSION : __( '확인 불가', 'nalapps-korean-woocommerce' ) ); ?></td></tr>
				<tr><th>HPOS</th><td><?php echo esc_html__( '호환 선언', 'nalapps-korean-woocommerce' ); ?></td></tr>
				<tr><th>Classic Checkout</th><td><?php echo esc_html__( '지원', 'nalapps-korean-woocommerce' ); ?></td></tr>
				<tr><th>Checkout Blocks</th><td><?php echo esc_html__( '현재 RC에서는 지원 보류', 'nalapps-korean-woocommerce' ); ?></td></tr>
				<tr><th><?php echo esc_html__( '휴대전화 검증', 'nalapps-korean-woocommerce' ); ?></th><td><?php echo esc_html__( '대한민국 청구지에만 적용', 'nalapps-korean-woocommerce' ); ?></td></tr>
				<tr><th><?php echo esc_html__( '우편번호 검증', 'nalapps-korean-woocommerce' ); ?></th><td><?php echo esc_html__( '대한민국 주소에만 5자리 검증 적용', 'nalapps-korean-woocommerce' ); ?></td></tr>
				</tbody>
			</table>
		</div>
		<?php
	}

	private function format_phone( string $phone ): string {
		$digits = preg_replace( '/\D+/', '', $phone );
		if ( is_string( $digits ) && preg_match( '/^(01[016789])(\d{3,4})(\d{4})$/', $digits, $matches ) ) {
			return $matches[1] . '-' . $matches[2] . '-' . $matches[3];
		}
		return sanitize_text_field( $phone );
	}

	private function format_postcode( string $postcode ): string {
		$digits = preg_replace( '/\D+/', '', $postcode );
		return is_string( $digits ) ? substr( $digits, 0, 5 ) : '';
	}

	private function is_valid_postcode( string $postcode ): bool {
		$digits = preg_replace( '/\D+/', '', $postcode );
		return is_string( $digits ) && 1 === preg_match( '/^\d{5}$/', $digits );
	}
}

new NalApps_Korean_WooCommerce();
