# 날라앱스 커머스 — 한국형 우커머스 애드온

대한민국 WooCommerce 운영환경에 맞게 주소, 우편번호와 휴대전화 입력을 보완하는 날라앱스 커머스 공식 애드온입니다.

> 이 저장소는 비공개 원본 소스 저장소입니다. 고객 설치·업데이트 ZIP은 공개 통합 배포 저장소 `Eoingtilab/nalapps-releases`에서만 배포합니다.

## 0.1.0-rc.1 구현 범위

- 대한민국 주소 필드 라벨과 입력 순서
- 대한민국 우편번호 5자리 정규화·검증
- 대한민국 청구지 휴대전화 정규화·검증
- 대한민국 주소 출력 형식
- 다른 국가의 전화번호·우편번호를 변경하지 않는 국가 범위 격리
- NalApps Commerce Core 관리자 하위 메뉴 통합
- WooCommerce HPOS 호환 선언
- Classic Checkout 지원

## 현재 RC 제한

- Checkout Blocks는 아직 Store API 기반 검증이 구현되지 않아 호환 가능으로 선언하지 않습니다.
- 다음 우편번호 검색, 국내 배송조회, 쇼핑피드, 분석과 상담버튼은 후속 RC 범위입니다.
- 실제 공개 운영 투입 전 Classic Checkout·HPOS 스테이징 회귀검사가 필요합니다.

## 요구사항

- WordPress 6.5 이상
- PHP 8.1 이상
- WooCommerce
- NalApps Commerce Core

WooCommerce 또는 Core가 비활성화된 경우 애드온 실행을 중단하고 관리자에게 의존성 안내만 표시합니다.

## 라이선스 및 업데이트

- Core 내장 무료 애드온으로 별도 시리얼을 요구하지 않습니다.
- Core 라이선스 및 공개 Commerce Catalog 정책을 따릅니다.
- 고객 설치 ZIP은 `nalapps-releases`의 `korean-woocommerce-current` 채널에서 제공합니다.
- 패키지는 SHA-256 검증 후 설치·업데이트됩니다.

## 개발 원칙

- WooCommerce 공개 API와 Hook 우선
- 대한민국 주소에만 한국형 정규화·검증 적용
- 테마 및 타 플러그인에 전역 CSS·JavaScript 미노출
- 지원하지 않는 Checkout 방식은 fail-closed
- 외부 API 장애가 주문 흐름을 손상시키지 않도록 기능별 격리

## 보안

고객 주문정보, API 키, 분석키와 외부 서비스 인증정보는 저장소와 공개 배포 메타데이터에 포함하지 않습니다.

## 저작권

Copyright © Eoingti Lab Inc. All rights reserved.
